# Change log

Record one entry per logical change, newest first. IDs CHG-001, CHG-002, etc. are stable. Preserve historical records; clarify mistakes with a dated correction. This log starts with specification workflow integration; earlier package/organisation history remains in [versions.md](versions.md).

## CHG-003 — 2026-10-25 — Source-aligned V0.2 rebuild
- Goal: implement the user's eleven corrections using supplied requirements only; restore S1 structure and stop service-selection page-top resets.
- Plan/mapping: [v02-plan.md](v02-plan.md); R03–R12,R18–R22; T19–T22; A01–A06,A10–A12,A15–A17.
- Before -> after: discretionary single-banner home -> three source slides, welcome, ten capabilities, social strip and certificate imagery; incomplete About -> all What We Do/values/leadership; navigational service cards -> photo family choice plus in-page service scope tabs.
- Files: company.ts, assets.json, HeroSlider/SocialLinks/CertificateGallery/CTA, Layout, home/About/certifications/services/detail pages, wording in equipment/contact/quote/careers/privacy, v02.css, verifier, package/lock version0.2.0, new supplied-image WebP assets. Existing form contract/dependencies unchanged. Original requirement/ preserved.
- Fixes: no route reload/forced scroll on explorer selection; accessible tab keyboard and URL context; small-screen About overflow fixed after browser discovery.
- Specs updated: plan/index, requirements R22/coverage, Design, architecture, decisions, tasks, acceptance, sources, versions, implementation-status, checkpoint, agents and project README. workflow.md reviewed and unchanged: same mandatory change discipline. Historical CHG-002 evidence preserved, not reused as current proof for changed UI.
- Validation:24-file Astro check with zero diagnostics;23-page build;799 local links/assets and source-section checks;7/7 tests;HTTP200. Chrome photo/service/search/deep-link/prefill/modal/keyboard/menu checks;16 responsive page-width observations with discovered320px About overflow fixed and affected check rerun. No captured browser errors. Exact evidence/limits in acceptance.md.
- Limits: four social destinations missing; independent source claims/contact/certificate/image-rights review; broader search/projects/resources, full accessibility/Lighthouse, timed/reduced-motion checks, live email/upload/CAPTCHA, production metadata/redirects/deployment/rollback pending. No fabricated business data or competitor superiority claim.
- Version: V0.2 local review; no database/API/deployment. Preview http://127.0.0.1:4321/ while existing loopback server runs. Separate source archive preserves V0.1. checkpoint.json hashes tested source/public/config state; source ZIP contains specs and excludes original references/intermediates.

## CHG-002 — 2026-10-24 UTC — Initial local review implementation
- Type: first application implementation, asset preparation, checks and documentation.
- User goal: implement the accepted fresh static initial version inside Jb-Service, without a database.
- Before -> after: planning files only -> 22 static review pages, 13 service detail pages, grouped equipment catalogue, service filtering/search, About/quality, careers and disconnected contact/quote/application interfaces.
- Files: package.json/lock, astro.config.mjs, tsconfig.json, .gitignore, .prettierrc.json, README.md; src/ templates/components/styles/data/lib; public/ optimised supplied imagery/logo/fonts/licenses/brochure; scripts/forms.test.mjs and verify.mjs. Original requirement/ input was not modified.
- Mapping: R01-R21 with partial coverage detailed in implementation-status.md; T01-T08 progressed, T10 service-search portion implemented; A01-A06,A09-A13 partially assessed. A07/A08/A14 remain pending live integration/release.
- Design: original navy/orange machinery-led theme; static hero; responsive mobile navigation; service cards/filter; contextual quotation; explicit preview labels. Equipment groups share one page, quality overview is under About, unverified future pages are omitted from navigation.
- Architecture: Astro 7.4.2 static build, TypeScript content, small browser scripts, local font files; no database/endpoints/storage or deployment. Upgraded initial scaffold dependency after audit findings; final audit total zero.
- Form contract: no data transmission; method=dialog plus prevented submission, bounded text prefill, native field validation and local metadata checks. Proposed enquiry policy is 2 GB aggregate/10 files; resume 5 MB/one file. Real storage and server validation remain required.
- Specs updated: README (status/index), Design (actual interactions), requirements (coverage link), architecture (actual preview), decisions (D12-D17/date correction), tasks (actual status), acceptance (evidence/limits), sources (asset provenance), versions (review checkpoint), agents (implementation status); added implementation-status.md and checkpoint.json.
- Unaffected spec: workflow.md reviewed; mandatory synchronisation procedure unchanged. No source requirement removed or launch approval inferred.
- Validation: Astro check 0 errors/warnings/hints; 7/7 Node tests; 22-page build; 710 local references passed; npm audit zero; HTTP 200. Chrome verified menu/Escape, filter/no-results, two contextual quote paths, native validation and honest preview result. No horizontal overflow across 16 four-width/page observations plus careers at 320px. Visual desktop/mobile review performed.
- Remaining limits: see acceptance.md. No Lighthouse or full automated accessibility audit; no live email/uploads/CAPTCHA; factual contacts/image/certificate/project approval, About expansion, broad search, redirects/canonicals/sitemap and production deployment/rollback pending.
- Version: V0.1 local initial review; uncommitted, no Git repository. Preview http://127.0.0.1:4321/ while local process runs. checkpoint.json binds evidence to source hashes; source archive excludes requirements/dependencies/intermediates.
- Historical note: earlier planning dates say 2026-10-25; this entry uses verified UTC date 2026-10-24. No earlier full acceptance PASS has been carried forward.

## CHG-001 — 2026-10-25 — Bind agent instructions to specifications
- Type: documentation / workflow.
- Request: keep all specifications aligned whenever code changes.
- Files: agents.md; spec/README.md; spec/workflow.md; spec/change-log.md; spec/tasks.md; spec/acceptance.md; spec/versions.md.
- R/T/A mapping: R01 iterative development; no application T/A execution (documentation-only).
- Result: mandatory before/after impact review, per-change records, evidence tracking and stale-result handling. Entire spec/ directory covered, including future documents.
- Specs unchanged: requirements, Design, architecture, decisions and sources; product scope, UI, technical plan and business evidence unchanged.
- Validation: relative Markdown link and required-file checks passed; no application build/tests applicable.
- Limits: guidance only; no watcher/hook/CI installed. Lowercase agents.md must be explicitly loaded in tools that require uppercase AGENTS.md.
- Version/commit: specification workflow revision; uncommitted, no application release.

## Entry template
- ID/date/title:
- Type and user goal:
- Implementation files changed:
- R/T/A IDs (or N/A rationale):
- Behaviour before -> after (or behaviour preserved):
- Spec files updated and reason:
- Unaffected specs reviewed and reason:
- Validation method/result/evidence and tested state:
- Invalidated acceptance results, if any:
- Remaining blockers/risks:
- Version/commit/preview (only when actually available):
