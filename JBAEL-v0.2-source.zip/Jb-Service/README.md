# JBAEL website — V0.2 source-aligned review

A new static website for JB Advanced Engineering Limited, built with Astro and TypeScript. All source and development work belongs inside this `Jb-Service` directory. Original reference documents and the old site remain in `requirement/`.

## Run locally

Use Node.js 22.12 or newer and npm. Tested with Node.js 26.5.0.

```sh
npm ci --cache .review/npm-cache
npm run dev
```

Open http://127.0.0.1:4321/. For the production build preview:

```sh
npm run build
npm run preview
```

The preview server remains running only while its terminal session is active. No production website has been deployed or changed.

## Checks

```sh
npm run check
npm test
npm run build
npm run verify
npm audit
```

`verify` checks generated page links, local assets, fragment targets, metadata, headings and preview form safeguards. `format` formats only the new source, scripts and Astro configuration. `requirement/` is excluded from type checking, formatting and build output.

## What is included

- Source-matched three-slide homepage, explicit Turbine/Generator/Boiler links, welcome, ten core capabilities, source social strip and responsive navigation/footer.
- Thirteen sourced service detail pages plus Thermal/Hydro photo selection, in-page service tabs and category search without page-top resets.
- Equipment catalogue with thermal, hydro and auxiliary groups.
- Complete source About/What We Do/Leadership/Vision/Mission/Goal; three certificate images with enlarge/download; Careers, Contact, Request a Quote, privacy and 404.
- Contextual service/component selection, local form validation and file metadata checks.
- Supplied imagery, extracted logo, downloadable company brochure and locally served fonts.

## Preview boundaries

There is no database, email endpoint, live upload, CAPTCHA, analytics or tracking integration. The forms never send data and explicitly disclose that. File selection checks metadata only; the 2 GB enquiry and 5 MB resume limits are provisional policies, not verified upload capabilities. Telephone/email links open the visitor's own applications.

Contact details and asset rights need company verification. Standards are shown as source-listed information, with certificate validation still pending. Careers is a future-opportunity expression-of-interest page, without invented vacancies. Verified projects, broader search, redirects, sitemap and live integrations remain on the backlog. LinkedIn uses the supplied legacy URL; the four other social destinations are pending and their icons are disabled. Certificate copies are shown for review; independent issuer verification is pending.

All pages intentionally use `noindex,nofollow` for review. Do not treat this build as production-ready. Production hosting, canonical domain, mail recipients, storage and retention must be configured and tested before cutover.

## Where to edit

- `src/data/company.ts`: sourced homepage, About and certificate content.
- `src/data/services.ts`: service copy, scope, categories and source references.
- `src/data/equipment.ts`: equipment catalogue.
- `src/data/assets.json`: photo source mapping.
- `src/pages/`: page content and routes.
- `src/components/EnquiryForm.astro`, `src/lib/forms.mjs`: disconnected form UI and metadata checks.
- `src/layouts/Layout.astro`, `src/styles/global.css`, `src/styles/v02.css`: shared design and source-aligned responsive layouts.
- `public/`: deployable images, fonts/licenses and brochure only.

Read [agents.md](agents.md) and [spec/README.md](spec/README.md) before every change. Follow the mandatory spec workflow and record each logical code change in [spec/change-log.md](spec/change-log.md). Current scope and verification are in [spec/implementation-status.md](spec/implementation-status.md).
