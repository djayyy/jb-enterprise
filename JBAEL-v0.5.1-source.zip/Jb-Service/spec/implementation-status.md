# V0.5.1 reference carousel and hover navigation checkpoint

CHG-007 · 25 October 2026 · Local, uncommitted source; no Git repository or deployment created. The V0.1, V0.2, V0.3 and V0.4.1 archives and historical acceptance record are preserved.

## Implemented routes

| Route | Content / interaction |
| --- | --- |
| `/` | Three large source themes with in-banner dots, side arrows and finite animation; welcome/Why JBAEL; four industries; ten capabilities; three certificate images; contact prompt |
| `/services/` | Three consistent Thermal/Hydro/Specialist photo selectors, 13 in-page scope panels, category search, stable tab selection, hover/focus dropdown scopes and deterministic deep links |
| `/services/thermal/{turbine,generator,boiler,electrical,control-instrumentation}/` | Five sourced detail pages with contextual enquiry |
| `/services/hydro/{turbine,generator,electrical-controls}/` | Three sourced detail pages |
| `/services/{testing-inspection,refurbishment,reverse-engineering,lubrication-reliability,oem-sourcing}/` | Five specialist pages; critical-component section under reverse engineering |
| `/equipment/` | Three matching category photo cards,12 equipment groups and47 parts with stable anchors and hover/focus dropdown, local category search/empty state, contextual quote links |
| `/about/` | Who We Are, approach, all six What We Do areas, Vision/Mission/Goal and complete source leadership message |
| `/certifications/` | Three supplied certificate images, descriptions, enlarged viewer and downloads |
| `/careers/` | Future-opportunity wording and application preview |
| `/contact/`, `/request-a-quote/` | Separate disconnected forms; query-string context prefill |
| `/privacy/`, `/404.html` | Preview policy and recovery navigation |

23 generated HTML pages. No database/email/storage/CAPTCHA integration. Versioned TypeScript data and static assets come from supplied requirements. Only LinkedIn has a sourced social destination; four other icons remain visibly pending.

## Coverage and remaining work
R03/R04 source branding, three-slide homepage hierarchy and explicit equipment are restored. R05 supplied About/leadership/mission content is complete for review. R06–R11 scopes and grouped equipment are represented; service scope summaries still require company technical review. R12 source certificate presentation is implemented; independent issuer verification remains pending. R13–R16 remain disconnected form interfaces with metadata checks only. R17 brochure supplied; project stories/articles/resources remain deferred. R18 service search works; resource/global search remains future work; equipment search now implemented. R19 no unmeasured superiority claim. R20 representative review checks recorded, full accessibility/performance/SEO/release work remains. R21 supplied reference imagery is used for review; rights and final real JBAEL photography need company approval. R22 requires source-only factual content and design fidelity.

Projects/resources/search and separate equipment category URLs are not exposed as broken destinations. Existing source discrepancies in contacts/addresses are retained as open review items. Certificate pixels were not changed to resolve those discrepancies.

## Verification
V0.5:28-file typecheck0 diagnostics,23-page build,20 tests,5495 link/asset references,1969 semantic checks and64 HTTP checks pass.258 unique destinations and all100 source service scopes/59 group-part anchors covered. Full page inventory and defect corrections: navigation-audit.md. Current preview http://127.0.0.1:4322/.

Browser visual/hover/scroll/keyboard/touch checks remain NOT RUN because no authorised browser-control tool is available. Earlier browser results are historical. No measured competitor superiority or full WCAG/Lighthouse claim.

Source manifest: spec/checkpoint.json. JBAEL-v0.5-source.zip includes source/public/config/specs, excluding original requirements, dependencies, build output and review intermediates. Prior source archives remain intact. No deployment or live integrations.

Current CHG-008 update: V0.5.1 covers the full banner with proportional image cropping; correct source dimensions and no underscale animation. Check/build/5495 references and HTTP200 rerun; earlier20 tests/64 HTTP checks remain V0.5 historical evidence. Current archive JBAEL-v0.5.1-source.zip; browser image framing NOT RUN.
