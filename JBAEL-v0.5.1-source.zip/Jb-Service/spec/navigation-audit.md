# V0.5 navigation audit

CHG-007 · 25 October 2026 · Local preview: http://127.0.0.1:4322/. Source hashes: checkpoint.json.

## Coverage
All 23 generated pages were audited, including service details, directories, About, Careers, forms, certificates, privacy and the 404 document. 5,495 local link/asset references and all associated fragments pass. 258 unique destinations, 1,969 query/context checks, 100 service scopes, 59 equipment targets (12 groups and47 individual parts), and9 CSS asset references pass.64 HTTP route/download/query requests pass; an additional unknown URL returns the branded404 with recovery links.

This is a source/generated-output/HTTP audit. Actual browser hover, clicking, rendering, keyboard/touch, screen-reader and scroll geometry are NOT RUN because no authorised browser-control tool is available. A passing link audit does not establish visual or interaction quality.

## Defects fixed
| Finding | Correction | Evidence |
| --- | --- | --- |
| Theme choices were outside the supplied carousel pattern | Dots inside banner, side arrows, source title overlay and lower action buttons | Supplied S1 pp.1–3 visually inspected; generated markup check |
| Breakdown required plus clicks; menus stayed open after pointer exit | Category/item hover and focus reveal successive panes; continuous trigger area and400ms leave grace | Implementation inspected; live browser check pending |
| Fragment-only Hydro/Specialist links selected Thermal | Resolver maps the service fragment to its real family | Regression tests and all13 service fragments |
| Search query could hide an explicitly requested service | Clear incompatible search; preserve a compatible one | Regression tests |
| Equipment Back to top jumped to catalogue | Preserve generic anchors such as main | Regression test |
| Individual component names all led to their group heading | Distinct part anchors with family reveal and target highlight |47 part destinations plus12 groups audited |
| Slow load/font completion could override user navigation | Cancel old arrival on interaction or newer navigation |3 scheduling unit tests with fixtures |
| Certificate popup intercepted Ctrl/Cmd-click | Preserve modified/native navigation | Source inspection; browser check pending |
| Shared slashless URLs showed a framework error | Accept both slash forms, normalise route-state detection | HTTP service/equipment queries200; unknown URL branded404 |
| Hero Explore Services ignored chosen theme | Theme-specific service destination updates with the slide | All3 configured destinations audited; browser change event pending |

## Page inventory
| Page | Local navigation references | Structural result |
| --- | ---: | --- |
| `/404.html` | 225 | PASS |
| `/about/` | 229 | PASS |
| `/careers/` | 226 | PASS |
| `/certifications/` | 231 | PASS |
| `/contact/` | 225 | PASS |
| `/equipment/` | 238 | PASS |
| `/` | 254 | PASS |
| `/privacy/` | 224 | PASS |
| `/request-a-quote/` | 226 | PASS |
| `/services/hydro/electrical-controls/` | 232 | PASS |
| `/services/hydro/generator/` | 232 | PASS |
| `/services/hydro/turbine/` | 232 | PASS |
| `/services/` | 264 | PASS |
| `/services/lubrication-reliability/` | 234 | PASS |
| `/services/oem-sourcing/` | 234 | PASS |
| `/services/refurbishment/` | 234 | PASS |
| `/services/reverse-engineering/` | 234 | PASS |
| `/services/testing-inspection/` | 234 | PASS |
| `/services/thermal/boiler/` | 234 | PASS |
| `/services/thermal/control-instrumentation/` | 234 | PASS |
| `/services/thermal/electrical/` | 234 | PASS |
| `/services/thermal/generator/` | 234 | PASS |
| `/services/thermal/turbine/` | 234 | PASS |

## Remaining boundaries
- Four social destinations remain disabled because official URLs are absent from the supplied requirements. LinkedIn is source-provided; no authenticated external-account verification performed.
- Phone/email links are correctly formed; no call/email was sent. Forms remain explicitly disconnected previews, with no invented delivery/upload success.
- Source certificates, brochure and images exist. Company validation of contacts, certificates and image rights remains pending.
- Unknown paths return404 locally; requesting the actual /404.html document directly returns200, which is normal for a static file. An initial audit expectation of404 for that explicit document was corrected.
- The old4321 preview process retained its earlier routing configuration and could not be stopped within current permissions. The current preview is4322. Production canonical redirects, legacy URL mapping and host-specific404 behaviour still need release configuration/testing; no production deployment was made.

## Reproduce
Run npm run check, npm test, npm run build, npm run verify, then npm run audit:navigation. For HTTP checks against the current preview: JBAEL_PREVIEW_URL=http://127.0.0.1:4322 npm run audit:navigation -- --http. Browser checks must be added separately.
