import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import ts from "typescript";
import {
  equipmentAnchor,
  partAnchor,
  resolveEquipmentSelection,
  resolveServiceSelection,
  equipmentArrivalTarget,
  serviceDetailUrl,
} from "../src/lib/navigation.mjs";
import { enquiryContext } from "../src/lib/forms.mjs";

async function sourceData(file) {
  const code = ts.transpileModule(fs.readFileSync(file, "utf8"), {
    compilerOptions: {
      module: ts.ModuleKind.ESNext,
      target: ts.ScriptTarget.ES2022,
    },
  }).outputText;
  return import(
    `data:text/javascript;base64,${Buffer.from(code).toString("base64")}`
  );
}
const { services } = await sourceData("src/data/services.ts");
const { equipment } = await sourceData("src/data/equipment.ts");
const { coreCapabilities } = await sourceData("src/data/company.ts");
const serviceEntries = services.map((s) => ({
  ...s,
  search: `${s.title} ${s.scope.join(" ")}`.toLowerCase(),
}));
const equipmentEntries = equipment.map((g) => ({
  group: g.group,
  anchors: g.items.flatMap((i) => [
    equipmentAnchor(g.group, i.title),
    ...i.parts.map((p) => partAnchor(g.group, i.title, p)),
  ]),
}));
const walk = (dir) =>
  fs
    .readdirSync(dir, { withFileTypes: true })
    .flatMap((e) =>
      e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)],
    );
const pages = walk("dist").filter((f) => f.endsWith(".html"));
const destinations = new Map();
const external = new Set();
const rows = [];
let mapped = 0;
for (const file of pages) {
  const route =
    "/" +
    path
      .relative("dist", file)
      .replaceAll(path.sep, "/")
      .replace(/index\.html$/, "");
  const html = fs.readFileSync(file, "utf8");
  let count = 0;
  for (const match of html.matchAll(/\b(?:href|data-url)="([^"]*)"/g)) {
    const ref = match[1].replaceAll("&amp;", "&");
    assert.ok(ref && ref !== "#", `Empty destination: ${file}`);
    if (!ref.startsWith("/") && !ref.startsWith("#")) {
      external.add(ref);
      continue;
    }
    const url = new URL(ref, "https://preview.invalid" + route);
    destinations.set(url.pathname + url.search + url.hash, url);
    count++;
    if (url.pathname === "/services/") {
      const state = resolveServiceSelection(
        url.search,
        url.hash,
        serviceEntries,
      );
      const expected =
        services.find((s) => s.slug === url.searchParams.get("service")) ||
        services.find(
          (s) => `#scope-${s.slug.replaceAll("/", "-")}` === url.hash,
        );
      if (expected) {
        assert.equal(state.selected, expected.slug);
        assert.equal(state.family, expected.group);
        assert.ok(
          !state.query ||
            serviceEntries
              .find((s) => s.slug === expected.slug)
              .search.includes(state.query.trim().toLowerCase()),
        );
      } else if (url.searchParams.has("group"))
        assert.equal(state.family, url.searchParams.get("group"));
      mapped++;
    }
    if (url.pathname === "/equipment/") {
      const state = resolveEquipmentSelection(
        url.search,
        url.hash,
        equipmentEntries,
      );
      const expected = equipmentEntries.find((g) =>
        g.anchors.includes(url.hash.slice(1)),
      );
      if (expected) {
        assert.equal(state.group, expected.group);
        assert.equal(state.query, "");
      } else if (url.searchParams.has("group"))
        assert.equal(state.group, url.searchParams.get("group"));
      if (url.hash === "#main")
        assert.equal(equipmentArrivalTarget(url.hash, ["main"]), "main");
      mapped++;
    }
    if (
      ["/contact/", "/request-a-quote/"].includes(url.pathname) &&
      url.search
    ) {
      const expected = ["service", "part", "need"]
        .map((k) => url.searchParams.get(k))
        .filter(Boolean)
        .join(" · ");
      assert.equal(enquiryContext(url.search), expected);
      assert.ok(
        fs
          .readFileSync(path.join("dist", url.pathname, "index.html"), "utf8")
          .includes('id="need"'),
      );
      mapped++;
    }
  }
  rows.push({ route, links: count });
}
const home = fs.readFileSync("dist/index.html", "utf8");
for (const capability of coreCapabilities) {
  const href = capability.anchor
    ? `/services/${capability.slug}/#${capability.anchor}`
    : serviceDetailUrl(capability.slug);
  assert.ok(
    home.includes(`href="${href}"`),
    `Missing capability destination ${capability.title}`,
  );
}
// Enumerate every possible scope and part, including those hidden until hover/filter selection.
for (const s of services) {
  for (const [index] of s.scope.entries())
    assert.ok(
      destinations.has(serviceDetailUrl(s.slug, index)),
      `Missing source scope link ${s.slug} ${index}`,
    );
  assert.equal(
    resolveServiceSelection(
      "",
      `#scope-${s.slug.replaceAll("/", "-")}`,
      serviceEntries,
    ).selected,
    s.slug,
  );
}
for (const g of equipmentEntries)
  for (const anchor of g.anchors) {
    assert.ok(
      destinations.has(`/equipment/?group=${g.group}#${anchor}`),
      `Missing part link ${anchor}`,
    );
    assert.equal(
      resolveEquipmentSelection(
        "?group=invalid&q=missing",
        `#${anchor}`,
        equipmentEntries,
      ).group,
      g.group,
    );
  }
let cssAssets = 0;
for (const file of walk("dist").filter((f) => f.endsWith(".css"))) {
  for (const m of fs
    .readFileSync(file, "utf8")
    .matchAll(/url\(["']?([^\s)'";]+)["']?\)/g)) {
    if (/^(data:|https?:|#)/.test(m[1])) continue;
    const clean = m[1].split(/[?#]/)[0];
    const dest = clean.startsWith("/")
      ? path.join("dist", clean)
      : path.resolve(path.dirname(file), clean);
    assert.ok(fs.existsSync(dest), `Missing CSS asset ${m[1]}`);
    cssAssets++;
  }
}
assert.equal(
  fs
    .readFileSync("dist/downloads/jbael-brochure.pdf")
    .subarray(0, 5)
    .toString(),
  "%PDF-",
);
console.log(
  JSON.stringify(
    {
      pages: rows,
      uniqueDestinations: destinations.size,
      semanticChecks: mapped,
      serviceScopes: services.reduce((n, s) => n + s.scope.length, 0),
      partTargets: equipmentEntries.reduce((n, g) => n + g.anchors.length, 0),
      cssAssets,
      externalDestinations: [...external],
      browserInteraction: "NOT RUN",
    },
    null,
    2,
  ),
);
if (process.argv.includes("--http")) {
  const base = process.env.JBAEL_PREVIEW_URL || "http://127.0.0.1:4321";
  const requests = [
    ...new Set([
      ...rows.map((r) => r.route),
      ...[...destinations.values()].map((u) => u.pathname + u.search),
    ]),
  ];
  const results = [];
  for (let i = 0; i < requests.length; i += 4) {
    results.push(
      ...(await Promise.all(
        requests.slice(i, i + 4).map(async (route) => {
          const response = await fetch(base + route, {
            signal: AbortSignal.timeout(10000),
          });
          assert.equal(response.status, 200, `HTTP destination ${route}`);
          await response.arrayBuffer();
          return { route, status: response.status };
        }),
      )),
    );
  }
  const missing = await fetch(base + "/__jbael_missing_page__", {
    signal: AbortSignal.timeout(10000),
  });
  assert.equal(missing.status, 404, "Missing URL must return 404");
  assert.ok((await missing.text()).includes("Home"), "404 recovery navigation");
  for (const route of ["/services?group=Hydro", "/equipment?group=other"]) {
    const response = await fetch(base + route, {
      signal: AbortSignal.timeout(10000),
    });
    assert.equal(response.status, 200);
    assert.equal(
      new URL(response.url).search,
      new URL(base + route).search,
      "Canonical redirect preserves query",
    );
    await response.arrayBuffer();
    results.push({ route, finalURL: response.url, status: response.status });
  }
  console.log(
    "PASS HTTP audit: " +
      JSON.stringify({ checked: results.length, missingRoute: 404, results }),
  );
}
