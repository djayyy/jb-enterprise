import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
const root = path.resolve("dist");
function walk(dir) {
  return fs
    .readdirSync(dir, { withFileTypes: true })
    .flatMap((e) =>
      e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)],
    );
}
const files = walk(root),
  pages = files.filter((f) => f.endsWith(".html")),
  titles = new Set();
let links = 0;
for (const page of pages) {
  const html = fs.readFileSync(page, "utf8");
  const title = html.match(/<title>(.*?)<\/title>/s)?.[1];
  assert.ok(title, `Missing title: ${page}`);
  assert.ok(!titles.has(title), `Duplicate title: ${title}`);
  titles.add(title);
  assert.equal((html.match(/<h1[\s>]/g) || []).length, 1, `One h1: ${page}`);
  assert.match(html, /<meta name="robots" content="noindex,nofollow"/);
  assert.match(html, /<meta name="description" content="[^"]+"/);
  assert.doesNotMatch(html, /lorem ipsum|XX MW|action="#"/i);
  for (const image of html.matchAll(/<img\b[^>]*>/g)) {
    assert.match(image[0], /\balt="/);
    assert.match(image[0], /\bwidth="\d+"/);
    assert.match(image[0], /\bheight="\d+"/);
  }
  for (const match of html.matchAll(/\b(?:href|src)="([^"]+)"/g)) {
    const ref = match[1].replaceAll("&amp;", "&");
    if (!ref.startsWith("/") && !ref.startsWith("#")) continue;
    const pageRoute =
      "/" +
      path
        .relative(root, page)
        .replaceAll(path.sep, "/")
        .replace(/index\.html$/, "");
    const url = new URL(ref, "https://preview.invalid" + pageRoute);
    let target = path.join(root, decodeURIComponent(url.pathname));
    if (url.pathname.endsWith("/")) target = path.join(target, "index.html");
    assert.ok(fs.existsSync(target), `Broken link ${ref} in ${page}`);
    links++;
    if (url.hash && target.endsWith(".html")) {
      const targetHtml = fs.readFileSync(target, "utf8");
      assert.ok(
        targetHtml.includes(`id="${decodeURIComponent(url.hash.slice(1))}"`),
        `Missing anchor ${ref} in ${page}`,
      );
    }
  }
  if (/<form\b/.test(html)) {
    assert.match(html, /<form[^>]*method="dialog"/);
    assert.match(html, /Nothing is sent, uploaded or saved/);
  }
}
assert.equal(pages.length, 22, "Expected review routes");
assert.ok(
  !files.some((f) => /\/requirement\/|\/spec\//.test(f)),
  "Private source documents must not be deployed",
);
console.log(
  `PASS: ${pages.length} pages; ${links} local links/assets; unique titles; metadata; image attributes; preview form safeguards.`,
);
