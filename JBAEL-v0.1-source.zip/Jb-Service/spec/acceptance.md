# Acceptance and verification

Status: CHG-002 has passed the recorded initial-review checks below. Full criteria remain partial or pending as specified. Preview completion is distinct from production readiness.

| ID | Requirements | Test / expected result |
| --- | --- | --- |
| A01 | R01,R03-R12,R16-R17 | Compare every source section with page map: all documented topics represented or explicitly deferred with reason; consistent JBAEL identity |
| A02 | R06-R11,R20 | From desktop and mobile menus reach each main category within two selections; detail pages and breadcrumbs work; no dead controls |
| A03 | R03-R21 | Audit claims/images: no XX MW, filler, invented jobs/results, wrong lubrication copy or unverified contact details in release |
| A04 | R20 | At 320,375,768,1280px no horizontal page overflow or clipped forms; keyboard menus, focus order, Escape and reduced-motion behaviour verified |
| A05 | R20 | Check WCAG 2.2 AA as target: labels, contrast, focus, semantics, alternative text and error announcements; automated checks plus manual keyboard review; no claim of certification |
| A06 | R20-R21 | Production build succeeds; links/assets resolve; image dimensions prevent major shifts; representative mobile Lighthouse performance target >=90, record settings/results; failure requires fix or documented tradeoff |
| A07 | R02,R13-R14 | Valid contact/quote reaches configured test inbox with correct subject/context and Reply-To; invalid/malicious input rejected; provider failure does not show success; no database writes |
| A08 | R15 | Under approved limit upload succeeds via private direct storage; over-limit/type violations fail server-side; interrupted transfer retry works; unauthorised/expired downloads fail; no public bucket; cleanup/retention verified |
| A09 | R16 | Careers accurately says future opportunities unless real jobs provided; valid resume reaches recipient; invalid files rejected; disconnected preview never claims sent |
| A10 | R10-R11,R18 | Part/service selection prepopulates enquiry; static search returns relevant results and usable empty state; no private form data in index |
| A11 | R12,R17,R21 | Certificate/brochure downloads open and are readable; project facts trace to source; asset permission/validity reviewed |
| A12 | R20 | Unique titles/descriptions/canonical URLs and sitemap; replaced legacy URLs redirect to relevant pages; preview not indexed; 404 provides recovery |
| A13 | R02,R20 | Secret scan clean; server-controlled recipients; CAPTCHA verified server-side; throttling exercised; private data excluded from routine logs; privacy text matches operation |
| A14 | R01 | Previous release identified and rollback rehearsed in preview; production DNS/email settings preserved; release and form smoke checks recorded |

## Evidence record template
- Acceptance ID / version / commit:
- Environment / device / date:
- Procedure and observed result:
- Evidence (test output or screenshot location):
- Status: PASS / FAIL / BLOCKED / NOT RUN
- Remaining risk or approved exception:

V0.1 gate: A01-A06,A10-A11 as applicable to review; disconnected integrations disclosed. V1.0 gate: all criteria assessed, no unresolved critical failure or fabricated result. External mail/storage access may block integration tests without blocking review pages.

## Evidence freshness
Follow [workflow.md](workflow.md). Every result must cite a CHG ID and the tested commit or an explicit uncommitted file-state description. Preserve past results as history; when affected code changes, mark current criteria NOT RUN until reverified. A prior-version PASS is not a current-version PASS.

## CHG-002 — V0.1 local review evidence, 2026-10-24 UTC
Environment: macOS, Node.js 26.5.0, Astro 7.4.2, connected Chrome, loopback production-build preview. No Git repository; tested source/public/config/script state is recorded by SHA-256 in checkpoint.json. Logs in .review/ are intermediate and not shipped in the source archive.

| ID | Current status | Observed evidence / remaining scope |
| --- | --- | --- |
| A01 | PARTIAL | 22 routes cover service/equipment groups; documented omissions in implementation-status.md. About expansion, verified certificates/projects/resources pending. |
| A02 | PASS for reviewed flows; PARTIAL overall | Mobile menu opened/closed; Escape returned focus to Menu; services -> generator -> quote and equipment -> quote worked. Generated link checker resolved 710 local href/src references and anchors. |
| A03 | PARTIAL | Output checker found no Lorem ipsum/XX MW/action="#"; no fabricated job entries. Provisional contacts and certificate verification visibly disclosed. Company factual/asset-rights review pending. |
| A04 | PARTIAL | Home, generator, quote, equipment checked at 320/375/768/1280, zero horizontal overflow in all 16 observations. Careers at 320 also passed. Desktop/mobile screenshots visually inspected. Full-page keyboard order, all browsers/pages and reduced-motion emulation not run. |
| A05 | PARTIAL / automated scan NOT RUN | Semantic heading/alt checks passed; native field labels and error/status areas inspected; keyboard menu checked. No WCAG compliance claim or full automated contrast/target/focus audit. |
| A06 | PARTIAL | Build passed with 22 pages; Astro check 19 files, 0 errors/warnings/hints; links/assets checked. Lighthouse score not measured. |
| A07 | NOT RUN / disconnected by design | No email endpoint/provider configured; browser valid-form check explicitly says nothing sent/uploaded/saved. Native empty-field submission rejected. |
| A08 | NOT RUN for uploads | Seven Node tests include 2 GB aggregate and 5 MB resume boundaries, types/count/zero-byte handling. Tests use file metadata, not actual uploads. Private storage, interrupted uploads, scanning/access/expiry unimplemented. |
| A09 | PARTIAL | Careers future-opportunity wording and preview form implemented; required-resume and format/size rules tested as metadata. Real resume delivery not configured. |
| A10 | PASS for implemented scope; PARTIAL broader search | Chrome Hydro filter returned 3 capabilities; impossible term showed empty state. Generator prefill and turbine-parts prefill observed. Bounded query context unit tests passed. Equipment/resource/global search pending. |
| A11 | PARTIAL | Copied supplied 32-page brochure and valid download link. Certificate downloads, company rights and project facts remain pending. |
| A12 | PARTIAL | All 22 pages have unique titles, descriptions, noindex and recovery navigation; link checker validates 404 links. Final canonicals, sitemap and legacy redirect map pending. |
| A13 | PARTIAL | npm audit reports 0 vulnerabilities for installed lockfile. No mail credentials, recipients, enquiry logging or API/storage code added. Production CAPTCHA/throttling/privacy/security checks not run. |
| A14 | NOT RUN | No deployment, Git release or production cutover; local source snapshot exists. Rollback rehearsal remains a launch task. |

### Exact observed command results
- `npm run check`: 19 files; 0 errors, 0 warnings, 0 hints.
- `npm test`: 7 tests; 7 pass; 0 fail.
- `npm run build`: 22 pages; completed successfully.
- `npm run verify`: PASS, 22 pages, 710 local links/assets; metadata/image/form checks.
- `npm audit --json`: metadata vulnerabilities total = 0.
- `curl -I http://127.0.0.1:4321/`: HTTP 200.
- Chrome quote empty submission: 6 required fields invalid; no preview confirmation. After synthetic example values: “The required fields pass the preview checks. Nothing has been sent, uploaded or saved. Live enquiries will be enabled in a later version.”

File-selection checks are client-only and cannot be used as security enforcement in production. Form browser tests used synthetic example data and did not send email. No previous full PASS results existed to invalidate. Future implementation changes must refresh affected evidence.
