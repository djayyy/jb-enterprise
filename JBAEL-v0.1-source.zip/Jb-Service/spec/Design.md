# Design specification

Status: V0.1 design implemented for review; company visual approval remains pending.

## Audience and tasks
Plant maintenance/engineering teams: find applicable support. Procurement: find parts and request a quote. Applicants: understand whether applications are for a vacancy or future opportunities.
Primary navigation: Home, Services, Equipment Supply, Projects, Company, Contact; persistent Request a Quote action. Company contains About, Certifications, Careers and Resources. This reorganises the supplied five-item navigation as a proposal.

## Page map
- /: homepage.
- /services/: category hub, with thermal, hydro and specialist groups.
- /services/thermal/{turbine,generator,boiler,electrical,control-instrumentation}/: five pages.
- /services/hydro/{turbine,generator,electrical-controls}/: three pages.
- /services/{testing-inspection,refurbishment,lubrication-reliability,reverse-engineering,oem-sourcing}/: specialist pages. Critical component development is a section of reverse engineering with its own anchor.
- /equipment/: searchable/filterable catalogue with thermal, hydro and other groups; /equipment/{thermal,hydro,other}/ category pages.
- /projects/: brochure-supported project summaries; individual pages only when source material supports meaningful detail.
- /about/, /certifications/, /resources/, /careers/, /contact/, /request-a-quote/, /privacy/, /search/, and 404 page.
These are proposed routes. Keep a legacy-to-new redirect map before cutover.

## Visual system
Deep blue, white, restrained orange aligned with approved logo. Authentic machinery/workshop photographs. Clear typography, readable technical lists, generous spacing, restrained motion. Avoid novelty animations and stock imagery presented as company facilities. Use semantic headings and visible focus states. Reflow from 320px through desktop without horizontal page scrolling. Respect reduced motion. Colour contrast and interaction target sizes must be checked, not assumed.

## Templates
Home: clear value proposition and service/quote actions; three supplied banner themes represented without compulsory autoplay; introduction; capability groups; industries; documented project evidence; certifications; contact prompt.
Service: equipment/context, work scope, process, relevant photos, source-backed project evidence when available, related parts and specific enquiry action.
Equipment category: application, supplied components, relevant images, related services and Enquire about this part. No invented SKU, price, stock or specifications.
Project: documented equipment/capacity, work performed and factual result only if supported. Hide unverified quantitative results.
Careers: future-opportunity application wording until approved jobs exist. No statement that no jobs exist unless company confirms it. Real vacancies can later be added from versioned files.
Certifications: legible image, standard name, download/enlarge action; inspect validity and entity before publishing.
Contact/quote: clear labels, required/optional markers, validation near fields, upload progress, error recovery and confirmation. No fake success.

## Journeys
Service -> contextual Quote (service preselected) -> submit -> email acceptance confirmation.
Part -> contextual Quote (component/category preselected) -> describe requirement -> submit.
Careers -> future-opportunity explanation -> application -> resume -> submit.
Search -> useful results with category labels; no-results message links to Contact.
Mobile navigation and dropdowns must work by touch and keyboard, not hover alone. Main categories should be reachable within two navigation selections.

## Content rules
Use S2 as provisional primary copy, S1 for structure and S3 for supporting evidence. Resolve conflicts explicitly. Remove XX MW, misspellings and repeated C&I text on lubrication card. Company claims need source records. Do not borrow competitor images or copy.

## CHG-002 first review scope
Implement the homepage and thermal generator detail first, with supporting Services, Equipment, Company/About and quote/contact review pages. Other detail pages can use a shared sourced template where available; do not expose broken future routes. Local preview only; no production deployment. Use extracted source logo and optimised source photographs, no competitor assets. Preview status is visible; enquiries must never be transmitted.

## CHG-002 implemented interaction details
Main navigation is Home, Services, Equipment, Company, Contact and Request a quote. Company points to About; Careers, quality and the brochure are reachable from the footer. Projects/resources destinations are deferred rather than linked to placeholders. The actual route map and remaining proposed routes are in implementation-status.md.

Deep navy/orange design uses locally served DM Sans/Manrope, supplied workshop imagery, a single static hero and no autoplay. Category cards have explicit detail links. Equipment is one grouped page with anchor navigation and contextual enquiry actions. Service directory has group buttons, live result count and text search across public service scopes. Empty results offer Contact.

Forms label required/optional fields and disconnected status before entry, retain entered values after the local check, and display file errors beside the picker. The action says “Check enquiry/application preview”; the result explicitly says nothing was sent/uploaded/saved. No fake CAPTCHA is rendered. Native required/email validation and local file metadata checks are active; live upload progress/retry is deferred.

Careers accepts no real submissions and describes future expressions of interest. Quality standards are described with an explicit verification note; no unverified certificate badge/download is presented as current proof. Full checklist and test limits remain in acceptance.md.
