# V0.1 initial review checkpoint

CHG-002 · 2026-10-24 UTC · Local, uncommitted source state; no Git repository or deployment created.

## Implemented routes

| Route | Content / interaction |
| --- | --- |
| `/` | Machinery-led homepage, service/industry groups, equipment, quality and enquiry prompts |
| `/services/` | 13 capabilities, Thermal/Hydro/Specialist filters, keyword search, no-results state |
| `/services/thermal/{turbine,generator,boiler,electrical,control-instrumentation}/` | Five source-backed service pages; generator has expanded component/process presentation |
| `/services/hydro/{turbine,generator,electrical-controls}/` | Three source-backed service pages |
| `/services/{testing-inspection,refurbishment,reverse-engineering,lubrication-reliability,oem-sourcing}/` | Five specialist pages; critical component anchor in reverse engineering |
| `/equipment/` | 12 equipment groups across thermal/hydro/auxiliary sections; contextual quote links |
| `/about/` | Company overview, approach and source-listed quality standards |
| `/careers/` | Future-opportunity wording and application preview |
| `/contact/`, `/request-a-quote/` | Separate form previews; query-string context prefill |
| `/privacy/` | Actual preview behaviour and future live-policy requirement |
| `/404.html` | Helpful recovery links |

22 generated HTML pages total, including 404. Data is maintained in TypeScript files. No database. No email/storage/CAPTCHA integrations.

## Coverage and deliberate deferrals

R01-R03: new isolated static implementation and source branding. Contacts remain provisional. R04: homepage themes represented in static sections instead of a carousel. R05: company overview/approach implemented; complete mission/vision/goal and approved leadership message remain for content refinement. R06-R11: service and equipment categories represented; current scope lists are editorial summaries of S2, requiring detailed company review before launch. R12: quality overview only; verified certificate presentation/downloads deferred. R13-R16: interfaces and local checks implemented; delivery/uploads/CAPTCHA deferred to launch integration. R17: supplied brochure download available; verified project stories and article migration deferred. R18: service search implemented; equipment/resource/global search pending. R19: original industrial visual direction; no measured superiority claim. R20: responsive baseline and checks below, with remaining launch checks. R21: supplied review imagery used, ownership/final company-photo approval pending.

The catalogue uses grouped sections instead of separate thin category URLs. Company quality information is at `/about/#quality`. Standalone `/certifications/`, `/projects/`, `/resources/`, `/search/` and `/equipment/{thermal,hydro,other}/` are not exposed as broken links. These proposed destinations remain eligible for later iterations.

## Verification summary

- Astro 7.4.2 static build: 22 pages; successful.
- Astro check: 19 files, zero errors/warnings/hints.
- Node tests: 7 passed; aggregate 2 GB boundary, 5 MB resume boundary, required resume, count/type/empty-file rejection, safe bounded query context.
- Generated-output verification: 710 local references resolved; unique titles, descriptions, one H1, noindex, image alt/dimensions, fragment targets and disconnected forms checked.
- npm audit: zero reported vulnerabilities at this checkpoint. This is not a general security certification.
- Chrome: service filters, no-results state, generator/equipment quote prefill, required-field rejection and explicit disconnected success text verified.
- Chrome: mobile menu open/close, Escape and focus return verified.
- Chrome: no horizontal overflow on home, generator, quote and equipment at viewport widths 320/375/768/1280; careers also checked at 320. Desktop and mobile screenshots visually inspected during review.
- Browser error log: no captured errors in the reviewed session.
- HTTP: local homepage returned 200. Brochure is a copied supplied 32-page PDF and link resolves.

Lighthouse and automated accessibility scanning were not run. Full keyboard journeys, reduced-motion emulation, all-page/browser/device coverage, certificate validity and production integration checks remain NOT RUN. Preview checks do not complete A01-A14 in full; see acceptance.md for individual status.

Reproduce command checks using README.md. Intermediate logs are in `.review/` (ignored). `spec/checkpoint.json` records SHA-256 of the tested implementation source and public assets. No screenshot or private form values are stored in the source snapshot.

## Next iteration

1. Review visual direction and wording with the company.
2. Refine About content, approved projects and certificate presentation; verify contact details and image rights.
3. Complete catalogue/global search and remaining accessibility/performance checks.
4. Confirm email recipients and upload policies; implement private storage and email delivery without an application database.
5. Add launch metadata/redirects, test the deployment and plan rollback before replacing production.
