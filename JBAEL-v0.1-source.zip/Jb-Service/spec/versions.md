# Versions and change control

## Release stages
V0.1: first complete review with supplied content, shared design and form UI; disconnected services disclosed.
V0.2: feedback, mobile/image refinement, catalogue/search and verified content.
V1.0: integrated email/uploads, completed acceptance evidence, redirects and launch readiness.
V1.1+: approved jobs, projects, resources and measured improvements.

Use one repository with small commits, named tags and preview branches. Do not maintain divergent copied site folders. Alternative visual explorations use branches and the same content baseline. A production-branch push may deploy automatically: verify pipeline before merging. Retain previous production deployment/commit and configuration rollback information.

For each version record date, commit, preview URL, changed requirement IDs, acceptance results, unresolved questions and next changes. No credentials or private enquiries in changelogs.

## Change log
2026-10-25 — Specification v0.1: agents.md and specification set created from reviewed source material and user decisions. No application code, hosting change, domain change or production deployment performed.

## Change template
Change / reason / affected R and A IDs / design and architecture implications / task updates / evidence / version.

2026-10-25 — Workspace organisation: installed agents.md and spec/ into Jb-Service/, relocated legacy source and all original reference documents/images into requirement/, and verified SHA-256 hashes for all moved files. Updated project boundaries and source paths. No website code changed.

2026-10-25 — [CHG-001](change-log.md): bound agents.md to the full spec directory, added mandatory change workflow and per-change log, and linked task/acceptance evidence. Documentation-only; application implementation remains not started.

## V0.1 initial implementation checkpoint — 2026-10-24 UTC
Change: CHG-002. State: local uncommitted review, 22 static pages, Astro 7.4.2, no application database or deployment. Preview: http://127.0.0.1:4321/ while the local preview process runs. Files and test evidence: implementation-status.md, acceptance.md and checkpoint.json. Source snapshot: JBAEL-v0.1-source.zip at project root; dependencies, generated build, original reference inputs and intermediate review files are excluded.

Build/typecheck/7 tests/710 internal references passed; npm audit zero reported vulnerabilities. Representative Chrome journeys and responsive checks passed. Live integrations, detailed content approval, full accessibility/performance testing and cutover remain pending. No commit, tag, remote repository or production rollback has been fabricated.
