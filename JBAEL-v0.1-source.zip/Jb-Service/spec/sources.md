# Sources and provenance

Baseline compiled from documents and code inspected in this conversation on 2026-10-24, and the subsequent agreed planning direction. Originals are now preserved under requirement/ at the Jb-Service project root. Paths below are relative to that root.

| ID | Source | Use |
| --- | --- | --- |
| S1 | requirement/D01. Docs - JBAEL Modification/Website Layout Design/Website Design layout-JBAEL-04092026-C - JBED202609016.pdf (47 pages) | Screen/section intent |
| S2 | requirement/D01. Docs - JBAEL Modification/Raw Data/JBAEL Website Raw Data - JBED202610057.pdf (15 pages; R00, 06.10.2026) | Primary content draft |
| S3 | requirement/JBAEL-Brochure-JBED23526003-R07-10MB.pdf (32 pages) | Capabilities and project evidence |
| S4 | requirement/picxele-jb-enterprise-main/ and requirement/D01. Docs - JBAEL Modification/Images For Website/ | Legacy code and images |
| S5 | https://www.mdaturbines.com/ and /careers/ | Competitor content/navigation benchmark |
| S6 | https://ppsvcs.com/ | Competitor content/navigation benchmark |

S4 photo inventory from prior inspection: Generator 47, Turbine 23, Electrical 21, Testings 18, C&I 9, Rewamping 5, 3D Scaning 4; total 127. Recheck actual files when restored.
S1 page references: home 1-9; about 10-12; services 13-26; equipment/specialisms 27-40; certificates 41-43; careers 44; contact 45; quote 46; image caveat 47.
Known conflicts: Mumbai addresses and office labels differ between S2 and S3; phone numbers differ; S1 contains XX MW and spelling/copy errors. Certificate images were visible in S1; authenticity/current validity was not independently verified.

## Technical references reviewed during planning
- https://docs.astro.build/en/guides/deploy/vercel/ : static deployment and previews.
- https://vercel.com/docs/functions/limitations : request body limit (4.5 MB at review); recheck before implementation.

Competitor comparison covers published content/navigation only. Browser visual inspection failed during the planning turn; no comparative speed/accessibility audit was completed. Do not describe the proposed site as proven superior.

## CHG-002 asset and content provenance
S2 was extracted locally and used for service scopes, equipment lists and provisional contact details; service/equipment data contains source page references. These are editorial summaries, not independent verification of company capability.
Logo: S1 page 1 embedded image xref 66, with its original alpha mask xref 2531 restored. Seven supplied S4 photographs were copied/resized to WebP; original relative filenames are in src/data/assets.json. Sources remain unchanged in requirement/. Their presence in supplied material does not establish ownership or that every image depicts a JBAEL facility; final R21 approval remains open.
Company brochure: S3 copied intact to public/downloads/jbael-brochure.pdf (32 pages). Do not treat brochure history/addresses as reconciled current business data.
Fonts: Google Fonts DM Sans and Manrope, retrieved from fonts.googleapis.com/fonts.gstatic.com and self-hosted; SIL Open Font License copies from the official google/fonts repository are in public/fonts/.
No competitor text or images were copied. No new comparative performance claim was made. Certificate images have not been published as verified certificates.
