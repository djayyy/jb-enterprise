import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
const root = path.resolve("dist");
function walk(dir) {
  return fs
    .readdirSync(dir, { withFileTypes: true })
    .flatMap((e) =>
      e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)],
    );
}
const files = walk(root),
  pages = files.filter((f) => f.endsWith(".html")),
  titles = new Set();
let links = 0;
for (const page of pages) {
  const html = fs.readFileSync(page, "utf8");
  const title = html.match(/<title>(.*?)<\/title>/s)?.[1];
  assert.ok(title, `Missing title: ${page}`);
  assert.ok(!titles.has(title), `Duplicate title: ${title}`);
  titles.add(title);
  assert.equal((html.match(/<h1[\s>]/g) || []).length, 1, `One h1: ${page}`);
  assert.match(html, /<meta name="robots" content="noindex,nofollow"/);
  assert.match(html, /<meta name="description" content="[^"]+"/);
  assert.doesNotMatch(html, /lorem ipsum|XX MW|action="#"/i);
  for (const image of html.matchAll(/<img\b[^>]*>/g)) {
    assert.match(image[0], /\balt="/);
    assert.match(image[0], /\bwidth="\d+"/);
    assert.match(image[0], /\bheight="\d+"/);
  }
  for (const match of html.matchAll(/\b(?:href|src)="([^"]+)"/g)) {
    const ref = match[1].replaceAll("&amp;", "&");
    if (!ref.startsWith("/") && !ref.startsWith("#")) continue;
    const pageRoute =
      "/" +
      path
        .relative(root, page)
        .replaceAll(path.sep, "/")
        .replace(/index\.html$/, "");
    const url = new URL(ref, "https://preview.invalid" + pageRoute);
    let target = path.join(root, decodeURIComponent(url.pathname));
    if (url.pathname.endsWith("/")) target = path.join(target, "index.html");
    assert.ok(fs.existsSync(target), `Broken link ${ref} in ${page}`);
    links++;
    if (url.hash && target.endsWith(".html")) {
      const targetHtml = fs.readFileSync(target, "utf8");
      assert.ok(
        targetHtml.includes(`id="${decodeURIComponent(url.hash.slice(1))}"`),
        `Missing anchor ${ref} in ${page}`,
      );
    }
  }
  if (/<form\b/.test(html)) {
    assert.match(html, /<form[^>]*method="dialog"/);
    assert.match(html, /Nothing is sent, uploaded or saved/);
  }
}
assert.equal(pages.length, 23, "Expected review routes");
assert.ok(
  !files.some((f) => /\/requirement\/|\/spec\//.test(f)),
  "Private source documents must not be deployed",
);
console.log(
  `PASS: ${pages.length} pages; ${links} local links/assets; unique titles; metadata; image attributes; preview form safeguards.`,
);

const home = fs.readFileSync(path.join(root, "index.html"), "utf8");
const about = fs.readFileSync(path.join(root, "about/index.html"), "utf8");
const hub = fs.readFileSync(path.join(root, "services/index.html"), "utf8");
for (const text of [
  "Turbine, Generator, Boiler",
  "OEM &amp; Non-OEM Turbine Generator Expertise",
  "Retrofitting &amp; Modernization Engineering",
  "Welcome to JB Advanced Engineering",
  "Why JBAEL?",
  "Core Engineering Services",
  "Industry Certifications",
]) {
  assert.ok(home.includes(text), `Missing source homepage section: ${text}`);
}
for (const text of [
  "What We Do",
  "Leadership Message",
  "Vision",
  "Mission",
  "Goal",
  "Skilled Field Services",
  "Inspection, Diagnostics",
]) {
  assert.ok(
    about.toLowerCase().includes(text.toLowerCase()),
    `Missing About source content: ${text}`,
  );
}
assert.equal(
  (home.match(/data-slide="/g) || []).length,
  3,
  "Three source hero themes",
);
assert.equal(
  (home.match(/class="core-card"/g) || []).length,
  10,
  "Ten core engineering capabilities",
);
assert.equal(
  (home.match(/class="certificate-card"/g) || []).length,
  3,
  "Three certificate images",
);
for (const html of [home, about, hub]) {
  assert.match(html, /linkedin\.com\/company\/jbenterpriseindia/);
  for (const name of ["YouTube", "Facebook", "Instagram", "X \/ Twitter"])
    assert.ok(html.includes(name));
  assert.doesNotMatch(html, /href="#"/, "No fake destinations");
}
assert.equal(
  (hub.match(/role="tabpanel"/g) || []).length,
  13,
  "All service scopes available in-page",
);
assert.match(hub, /data-family="Thermal"/);
assert.match(hub, /data-family="Hydro"/);
console.log(
  "PASS: source fidelity checks — 3 slides, 10 core capabilities, 3 certificates, full About sections, social destinations and 13 in-page service scopes.",
);

const parts = fs.readFileSync(path.join(root, "equipment/index.html"), "utf8");
assert.equal(
  (hub.match(/class="category-card"/g) || []).length,
  3,
  "Three equal service category cards",
);
assert.equal(
  (parts.match(/class="category-card"/g) || []).length,
  3,
  "Three equal equipment category cards",
);
assert.match(hub, /data-family="Specialist"/);
assert.equal(
  (parts.match(/<article[^>]*data-part-card/g) || []).length,
  12,
  "All twelve source part groups retained",
);
assert.doesNotMatch(
  home,
  /class="(?:core-index|industry-number)"|<span>0[123]<\/span>/,
  "No decorative home numbering",
);
assert.match(home, /Auto-rotate off/);
assert.match(parts, /data-no-parts/);
console.log(
  "PASS: V0.3 category consistency, source parts coverage, clear rotation control and numbering removal.",
);
