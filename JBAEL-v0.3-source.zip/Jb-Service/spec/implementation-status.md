# V0.3 navigation and image refinement checkpoint

CHG-004 · 25 October 2026 · Local, uncommitted source; no Git repository or deployment created. The V0.1 and V0.2 archives and historical acceptance record are preserved.

## Implemented routes

| Route | Content / interaction |
| --- | --- |
| `/` | Three full-image source themes with named thumbnail controls and explicit auto-rotate; Turbine/Generator/Boiler; welcome/Why JBAEL; four industries; ten capabilities; three certificate images; contact prompt |
| `/services/` | Three consistent Thermal/Hydro/Specialist photo selectors, 13 in-page scope panels, category search, stable tab selection and deep links |
| `/services/thermal/{turbine,generator,boiler,electrical,control-instrumentation}/` | Five sourced detail pages with contextual enquiry |
| `/services/hydro/{turbine,generator,electrical-controls}/` | Three sourced detail pages |
| `/services/{testing-inspection,refurbishment,reverse-engineering,lubrication-reliability,oem-sourcing}/` | Five specialist pages; critical-component section under reverse engineering |
| `/equipment/` | Three matching category photo cards,12 equipment groups, local category search/empty state, contextual quote links |
| `/about/` | Who We Are, approach, all six What We Do areas, Vision/Mission/Goal and complete source leadership message |
| `/certifications/` | Three supplied certificate images, descriptions, enlarged viewer and downloads |
| `/careers/` | Future-opportunity wording and application preview |
| `/contact/`, `/request-a-quote/` | Separate disconnected forms; query-string context prefill |
| `/privacy/`, `/404.html` | Preview policy and recovery navigation |

23 generated HTML pages. No database/email/storage/CAPTCHA integration. Versioned TypeScript data and static assets come from supplied requirements. Only LinkedIn has a sourced social destination; four other icons remain visibly pending.

## Coverage and remaining work
R03/R04 source branding, three-slide homepage hierarchy and explicit equipment are restored. R05 supplied About/leadership/mission content is complete for review. R06–R11 scopes and grouped equipment are represented; service scope summaries still require company technical review. R12 source certificate presentation is implemented; independent issuer verification remains pending. R13–R16 remain disconnected form interfaces with metadata checks only. R17 brochure supplied; project stories/articles/resources remain deferred. R18 service search works; resource/global search remains future work; equipment search now implemented. R19 no unmeasured superiority claim. R20 representative review checks recorded, full accessibility/performance/SEO/release work remains. R21 supplied reference imagery is used for review; rights and final real JBAEL photography need company approval. R22 requires source-only factual content and design fidelity.

Projects/resources/search and separate equipment category URLs are not exposed as broken destinations. Existing source discrepancies in contacts/addresses are retained as open review items. Certificate pixels were not changed to resolve those discrepancies.

## Verification
Current command/browser evidence and limitations are in acceptance.md under CHG-004.25-file Astro check,23-page build,804 local links/assets, source/category checks and7 tests pass. Home/services/equipment have zero overflow at320/375/768/1280. Timed hero progression, stop state, keyboard selection, stable service scrolling, Specialist category, equipment empty/search/reset and contextual enquiry reviewed. No measured competitor superiority or full WCAG/Lighthouse claim.

Source hash manifest: spec/checkpoint.json. JBAEL-v0.3-source.zip preserves this version and excludes originals, dependencies, generated build and review intermediates. No deployment or live integrations. See README for reproduction.
