# Design specification

Status: V0.3 implemented for local review; company approval remains pending. CHG-004 supersedes conflicting earlier hero and category presentation choices.

## Audience and tasks
Plant maintenance/engineering teams: find applicable support. Procurement: find parts and request a quote. Applicants: understand whether applications are for a vacancy or future opportunities.
Current primary navigation: Home, About, Services, Equipment Supply, Contact and Request a Quote, matching S1. Certifications, Careers and brochure are linked from the footer. Projects/resources remain future scope.

## Page map
- /: homepage.
- /services/: category hub, with thermal, hydro and specialist groups.
- /services/thermal/{turbine,generator,boiler,electrical,control-instrumentation}/: five pages.
- /services/hydro/{turbine,generator,electrical-controls}/: three pages.
- /services/{testing-inspection,refurbishment,lubrication-reliability,reverse-engineering,oem-sourcing}/: specialist pages. Critical component development is a section of reverse engineering with its own anchor.
- /equipment/: searchable/filterable catalogue with thermal, hydro and other groups; /equipment/{thermal,hydro,other}/ category pages.
- /projects/: brochure-supported project summaries; individual pages only when source material supports meaningful detail.
- /about/, /certifications/, /resources/, /careers/, /contact/, /request-a-quote/, /privacy/, /search/, and 404 page.
These are proposed routes. Keep a legacy-to-new redirect map before cutover.

## Visual system
Deep blue, white, restrained orange aligned with approved logo. Authentic machinery/workshop photographs. Clear typography, readable technical lists, generous spacing, restrained motion. Avoid novelty animations and stock imagery presented as company facilities. Use semantic headings and visible focus states. Reflow from 320px through desktop without horizontal page scrolling. Respect reduced motion. Colour contrast and interaction target sizes must be checked, not assumed.

## Templates
Home: clear value proposition and service/quote actions; three supplied banner themes represented without compulsory autoplay; introduction; capability groups; industries; documented project evidence; certifications; contact prompt.
Service: equipment/context, work scope, process, relevant photos, source-backed project evidence when available, related parts and specific enquiry action.
Equipment category: application, supplied components, relevant images, related services and Enquire about this part. No invented SKU, price, stock or specifications.
Project: documented equipment/capacity, work performed and factual result only if supported. Hide unverified quantitative results.
Careers: future-opportunity application wording until approved jobs exist. No statement that no jobs exist unless company confirms it. Real vacancies can later be added from versioned files.
Certifications: legible image, standard name, download/enlarge action; inspect validity and entity before publishing.
Contact/quote: clear labels, required/optional markers, validation near fields, upload progress, error recovery and confirmation. No fake success.

## Journeys
Service -> contextual Quote (service preselected) -> submit -> email acceptance confirmation.
Part -> contextual Quote (component/category preselected) -> describe requirement -> submit.
Careers -> future-opportunity explanation -> application -> resume -> submit.
Search -> useful results with category labels; no-results message links to Contact.
Mobile navigation and dropdowns must work by touch and keyboard, not hover alone. Main categories should be reachable within two navigation selections.

## Content rules
Use S2 as provisional primary copy, S1 for structure and S3 for supporting evidence. Resolve conflicts explicitly. Remove XX MW, misspellings and repeated C&I text on lubrication card. Company claims need source records. Do not borrow competitor images or copy.

## CHG-002 first review scope
Implement the homepage and thermal generator detail first, with supporting Services, Equipment, Company/About and quote/contact review pages. Other detail pages can use a shared sourced template where available; do not expose broken future routes. Local preview only; no production deployment. Use extracted source logo and optimised source photographs, no competitor assets. Preview status is visible; enquiries must never be transmitted.

## CHG-002 implemented interaction details
Main navigation is Home, Services, Equipment, Company, Contact and Request a quote. Company points to About; Careers, quality and the brochure are reachable from the footer. Projects/resources destinations are deferred rather than linked to placeholders. The actual route map and remaining proposed routes are in implementation-status.md.

Deep navy/orange design uses locally served DM Sans/Manrope, supplied workshop imagery, a single static hero and no autoplay. Category cards have explicit detail links. Equipment is one grouped page with anchor navigation and contextual enquiry actions. Service directory has group buttons, live result count and text search across public service scopes. Empty results offer Contact.

Forms label required/optional fields and disconnected status before entry, retain entered values after the local check, and display file errors beside the picker. The action says “Check enquiry/application preview”; the result explicitly says nothing was sent/uploaded/saved. No fake CAPTCHA is rendered. Native required/email validation and local file metadata checks are active; live upload progress/retry is deferred.

Careers accepts no real submissions and describes future expressions of interest. Quality standards are described with an explicit verification note; no unverified certificate badge/download is presented as current proof. Full checklist and test limits remain in acceptance.md.

## CHG-003 current design and interactions — V0.2
The source-aligned sequence and page references are binding in [v02-plan.md](v02-plan.md). Home follows S1 pp.1–9: orange contact/social strip; five-item navigation; three selectable image banners; explicit Turbine/Generator/Boiler links; welcome/Why JBAEL; four industry photo cards; ten capabilities; three certificate thumbnails and contact prompt. Carousel is manual by default, supports arrows/labelled selectors and optional play/pause; keyboard, focus/hover pause and reduced-motion handling are implemented.

About follows pp.10–12, including all six What We Do areas and full unattributed leadership commitments alongside Vision/Mission/Goal. No invented leader portrait/name. What We Do becomes one column at narrow mobile widths to avoid overflow.

Services follows p.13 with Thermal/Hydro background-image buttons. Category selection updates services below; service tabs update one scope panel in the same document. No scrollTo/location navigation occurs on selection. The URL retains group/service/search via replaceState, enabling shareable deep links. Vertical arrow/Home/End keys change tabs; empty search offers Clear search and Contact. Dedicated detail pages remain; related-service links open the explorer at its content anchor. Scope panels reserve minimum height to reduce scroll clamping when switching long/short lists. Explicit navigation to a different route still navigates normally.

Certificate cards show supplied originals without altering their content, converted to WebP for delivery. Enlarge uses a native dialog with Escape, close button and focus recovery; image links remain usable without JavaScript. Downloads resolve to the certificate image. The review note distinguishes supplied copies from issuer verification.

Only the supplied LinkedIn destination is active; X/Twitter, YouTube, Facebook and Instagram icons are visibly disabled/pending, not fabricated links. Preview forms and data policies are unchanged. Projects/global search and live form interactions remain future scope, not silently completed by this version.

## CHG-004 V0.3 current presentation
[Plan](v03-plan.md): full-image split hero with source text alongside uncropped object-fit:contain imagery. Three named thumbnail selectors replace numbered controls; previous/next and explicit Auto-rotate/Stop auto-rotate have visible status. Start advances immediately, then every6 seconds. Manual changes stop rotation. No hover cancellation. Hidden document, external focus entry or changed motion preference stops it. Transitions use opacity/short translation; reduced-motion media query removes motion. No synthetic 3D rotation or new machinery imagery.

Home equipment shortcuts, industry/capability cards and About What We Do/values lose decorative numbering. Ten capability cards now use a regular responsive grid. Source content retained.

Services and Equipment share CategoryCards: equal photo header, title, short source-category summary, named action and Selected badge. Specialist and Auxiliary use the supplied workshop image. Mobile uses compact image/text rows. Services retain stable in-page tabs/scopes with Choose a service label. Equipment groups switch in-page, filter within selected group, report results and provide Clear search/Contact recovery; parts enquiry links preserve selection. Deep links support group/q and legacy category hashes. No numbering implies workflow steps. Existing certificate, form and source-copy rules remain.
