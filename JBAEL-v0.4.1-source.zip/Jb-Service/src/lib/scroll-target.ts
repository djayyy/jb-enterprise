/** Run after the destination content is visible; native hashes can fire too early. */
export function revealTarget(id: string, smooth = false) {
  requestAnimationFrame(() => {
    const target = document.getElementById(id);
    if (!target || !target.getClientRects().length) return;
    const header = document.querySelector<HTMLElement>(".header");
    const offset = (header?.getBoundingClientRect().height || 90) + 24;
    const top = target.getBoundingClientRect().top + window.scrollY - offset;
    window.scrollTo({
      top: Math.max(0, top),
      behavior:
        smooth && !matchMedia("(prefers-reduced-motion: reduce)").matches
          ? "smooth"
          : "instant",
    });
  });
}
export function settleTarget(id: string) {
  const reveal = () => {
    void document.fonts.ready.then(() => revealTarget(id));
  };
  if (document.readyState === "complete") reveal();
  else window.addEventListener("load", reveal, { once: true });
}
